# KILIMA ATELIER — Fashion House & Design Studio Platform

A unified luxury digital atelier and operational suite for an independent Nigerian fashion house, combining bespoke client commissions, ready-to-wear collections, and an end-to-end studio operating system (client measurement vault, cost-based pricing engine, order stage lifecycle, and tailor production tracker).

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and brand decisions were confirmed during the alignment phase and will guide the build:

- **Confirmed Application Focus**: Full Studio Suite — an integrated dual-mode application serving both high-end private clients (bespoke commissions, style lookbook, ready-to-wear shopping, measurement profile submission) and the internal studio team (10-stage order pipeline, measurement vault, fabric & production cost calculator, tailor assignments, and deposit ledger).
- **Confirmed Brand Name & Positioning**: **KILIMA ATELIER** — *"Modern Elegance Meets African Luxury"*, celebrating Nigerian textile artistry (Ankara, Aso-Oke, Senator, Agbada) combined with contemporary Western tailoring.
- **Confirmed Aesthetic Direction**: **Warm Saharan Luxury** — deep terracotta (`#C85A32`), rich obsidian canvas (`#121110` / `#1A1816`), warm desert sand (`#F4EFEA`), and burnished antique gold accents (`#D4AF37`), styled with high-contrast editorial typography (`Bodoni Moda` / `Playfair Display` headers paired with `Plus Jakarta Sans` body and tabular figures).

---

### 1. Overview & Core Concept

#### What It Does
KILIMA ATELIER bridges the gap between client-facing haute couture and lean back-office execution for an independent fashion house starting with ₦0–₦200,000 in seed capital:
1. **Client Experience**: Browse signature RTW collections (Affordable, Classic, Premium tiers), launch a custom bespoke commission with fabric selection and style customizer, book in-person or virtual styling consultations, and submit precise anatomical measurements.
2. **Studio Operating System (Atelier OS)**: Manage the complete 10-step PRD order lifecycle (Inquiry $\to$ Deposit $\to$ Fabric Sourcing $\to$ Cutting $\to$ Sewing $\to$ Fitting $\to$ Final Delivery), compute cost-based pricing with deposit milestones (protecting lean working capital), track internal vs. external tailor tasks, and maintain customer measurement cards.

#### Target Audience & Personas
- **Private Clients**: Men, women, and couples seeking traditional African occasion wear (Agbada, Senator, Aso-Oke bridal), corporate workwear, or modern Ankara dresses.
- **Institutional & Bulk Clients**: School boards, corporate hospitality managers, and event committees requesting uniform and mass-production contracts.
- **Lead Fashion Designer & Studio Manager**: Oversees creative direction, sets pricing margins, inspects garment finishing, and manages production schedules.
- **In-House & Partner Tailors**: View assigned cutting and stitching tickets with exact measurement specifications and target delivery dates.

#### Key Value
- **Zero Cash Drag**: Upfront deposit calculation (default 60–70% material and cutting deposit) ensures customer funds finance fabrics before cutting starts, directly solving the lean capital constraint identified in the PRD.
- **Flawless Fit Guarantee**: Centralized measurement profiles eliminate tailor guesswork and reduce alteration costs.

---

### 2. User Experience & Visual Design

#### Key User Flows

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CLIENT / PATRON FLOW                            │
└────────────────────────────────────────────────────────────────────────┘
 [Atelier Landing] ───► [Explore RTW Collections] ───► [Bag & Deposit Checkout]
         │
         ├───► [Custom Bespoke Builder] ──► [Fabric/Style] ──► [Measurement Intake]
         │
         └───► [Client Order Tracker] ──► [Input Order Code] ──► [Live Status Stage]

┌────────────────────────────────────────────────────────────────────────┐
│                        STUDIO BACKSTAGE FLOW                           │
└────────────────────────────────────────────────────────────────────────┘
 [Atelier OS Dashboard] ───► [Active 10-Stage Pipeline] ───► [Update Stage & Notes]
         │
         ├───► [Cost & Price Engine] ──► [Fabric + Notions + Labor + Margin]
         │
         ├───► [Client Measurement Vault] ──► [Search/Add Profile & PDF/Print Card]
         │
         └───► [Bulk Contract Manager] ──► [Uniforms & Institutional Production]
```

1. **Client Experience**:
   - **Hero & Curated Showcase**: Cinematic campaign showcase highlighting KILIMA's modern African luxury identity, with direct entry into Bespoke Commissions and the Ready-to-Wear catalog.
   - **Bespoke Commission Studio**: Interactive garment builder allowing customers to pick attire type (Senator, Agbada, Ankara Ball Gown, Corporate Kaftan, Aso-Oke Occasion), fabric preferences, neckline/sleeve details, and delivery urgency.
   - **Measurement Intake Form**: Visual guide explaining how to measure chest/bust, waist, hip, shoulder width, sleeve length, agbada span, and inseam with unit toggle (inches/cm).
   - **Direct Order Status Tracker**: Clients enter their order ID to view their garment's real-time progression through the 10 PRD production milestones.

2. **Studio Operations (Atelier OS)**:
   - **Kanban Order Pipeline**: Visual drag-and-drop or segmented progression across:
     *Stage 1: Inquiry* $\to$ *Stage 2: Design Selected* $\to$ *Stage 3: Measurement Taken* $\to$ *Stage 4: Deposit Paid* $\to$ *Stage 5: Fabric Sourced* $\to$ *Stage 6: In Production (Cutting/Sewing)* $\to$ *Stage 7: Quality Inspection* $\to$ *Stage 8: Fitting Scheduled* $\to$ *Stage 9: Final Payment* $\to$ *Stage 10: Delivered*.
   - **Cost-Based Pricing Calculator**: Form to input fabric yardage, cost per yard, sewing notions/zippers/lining, tailor labor hours/rate, packaging, and desired markup percentage (outputting minimum recommended retail price and required 60% deposit).
   - **Measurement Vault**: Searchable client directory storing full measurement cards, body notes, preferred cuts, and order history.
   - **WhatsApp Invoice & Quote Generator**: One-click generation of formatted WhatsApp messages ready to send to Nigerian clients with deposit instructions, bank account details, and delivery milestones.

#### Visual Identity & Theme
- **Aesthetic**: Warm Saharan Luxury — tactile, high-fashion, confident, and rooted in African heritage.
- **Palette Tokens**:
  - `Canvas / Neutral`: Deep Rich Obsidian (`#121110`) and warm textured basalt (`#1C1A18`) for studio elegance, with soft warm ivory (`#FBF8F5`) and travertine sand (`#F4EFEA`) for clean editorial reading.
  - `Primary / Accent`: Burnished Sahara Gold (`#D4AF37` / `#C59B27`) and Warm Terracotta Clay (`#C85A32`).
  - `Hairlines & Dividers`: Subtle bronze border lines (`rgba(212, 175, 55, 0.15)` and `rgba(255, 255, 255, 0.08)`).
- **Typography**:
  - *Display / Headlines*: `Bodoni Moda` / `Playfair Display` (Luxury serif, high contrast, elegant letter spacing).
  - *Body Prose*: `Plus Jakarta Sans` (14px–16px, readable, balanced rhythm).
  - *Prices & Measurements*: Monospace tabular figures (`tabular-nums font-mono`) for precision alignment of financial figures and inch/centimeter measurements.
- **Zero-Pill Discipline**: Informational metadata (fabric types, collection tiers, garment specs) is styled with subtle typographic dividers (`·` and `/`), reserving buttons strictly for actionable controls.

---

### 3. Key Product Decisions & Trade-Offs

- **Integrated Client Showcase + Studio OS Toggle**:
  - *Chosen Approach*: Single high-performance web application with a discreet, accessible mode toggle in the secondary toolbar allowing seamless switching between the client-facing Atelier experience and the internal Studio OS.
  - *Why*: Allows the business owner to demonstrate the brand to clients on a tablet or phone, and immediately switch to back-office order entry and costing during client consultations.
  - *Alternative Considered*: Separating client site and admin console into two different domains or repos, which increases initial maintenance overhead during the lean phase.

- **Offline-First Local Persistence with Export/Import**:
  - *Chosen Approach*: Fast, reliable client-side browser persistence (`localStorage`) pre-seeded with rich sample orders, RTW garments, client measurement cards, and pricing templates, backed by an instant JSON Backup & Restore utility.
  - *Why*: Enables instant zero-latency usage on mobile devices or studio laptops without database costs or backend latency, perfectly adhering to the ₦0–₦200,000 lean budget constraint.

- **Deposit-Gated Order Progression**:
  - *Chosen Approach*: The studio workflow enforces deposit receipt before moving orders into "Fabric Sourcing" or "In Production", with a visual alert flag if material expenses are incurred without deposit.
  - *Why*: Directly mitigates Risk #1 ("Insufficient startup capital") and Risk #8 ("Customer payment defaults") specified in Section 14 of the PRD.

---

### 4. Technical Architecture & Data Strategy

#### System & Component Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                         KILIMA ATELIER APP                             │
└────────────────────────────────────────────────────────────────────────┘
                                    │
           ┌────────────────────────┴────────────────────────┐
           ▼                                                 ▼
┌───────────────────────┐                         ┌──────────────────────┐
│  CLIENT EXPERIENCE    │                         │  STUDIO BACKSTAGE    │
├───────────────────────┤                         ├──────────────────────┤
│ • TopBar (Wordmark,   │                         │ • Backstage Header   │
│   Nav, Primary CTA)   │                         │ • Pipeline Kanban    │
│ • Hero Showcase       │                         │   (10 PRD Stages)    │
│ • RTW Catalog Grid    │                         │ • Pricing & Costing  │
│   (Affordable/        │                         │   Calculator (₦)     │
│    Classic/Premium)   │                         │ • Measurement Vault  │
│ • Bespoke Builder &   │                         │ • Bulk Contract Hub  │
│   Measurement Guide   │                         │ • WhatsApp Messenger │
│ • Client Order Lookup │                         │ • Backup / Restore   │
└───────────────────────┘                         └──────────────────────┘
           │                                                 │
           └────────────────────────┬────────────────────────┘
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        DATA & STORAGE LAYER                            │
├────────────────────────────────────────────────────────────────────────┤
│ • Atelier Store (localStorage + State Hooks)                           │
│   - Orders Store (10 stages, deposits, balance, client specs)          │
│   - Client Profiles & Measurement Vault (anatomical specs, notes)      │
│   - RTW Inventory (tiers, sizes, prices, images, stock)                │
│   - Cost Calculator Presets (fabric costs, labor rates, margins)       │
└────────────────────────────────────────────────────────────────────────┘
```

#### Core Data Entities

1. **Order Record (`AtelierOrder`)**:
   - `id`: Unique tracking code (e.g., `KLM-8421`)
   - `clientName`, `phone`, `email`, `deliveryAddress`
   - `division`: `'bespoke' | 'ready_to_wear' | 'bulk_production' | 'styling'`
   - `collectionTier`: `'affordable' | 'classic' | 'premium'`
   - `garmentType`: (e.g., Agbada 3-piece, Kaftan Senator, Ankara Mermaid Gown)
   - `stage`: Current stage (1 through 10)
   - `fabricSuppliedBy`: `'client' | 'atelier'`
   - `fabricDetails`: yardage, description, color
   - `costBreakdown`: fabricCost, notionsCost, tailorLabor, packaging, totalCost
   - `pricing`: quotedPrice, depositRequired, depositPaid, balanceDue
   - `measurementsId`: Reference to client measurement card
   - `assignedTailor`: Name and contact of internal/external production partner
   - `targetDeliveryDate`: ISO date string

2. **Client Measurement Profile (`ClientMeasurementCard`)**:
   - `id`, `fullName`, `gender`, `phone`, `email`, `notes`
   - `unit`: `'inches' | 'cm'`
   - `anatomicalValues`: neck, chestBust, underbust, waist, hip, shoulderWidth, sleeveLength, bicep, wrist, shirtLength, trouserLength, waistToKnee, thigh, ankle, agbadaSpan, capSize

3. **Ready-to-Wear Garment (`RTWItem`)**:
   - `id`, `name`, `tier` (`'affordable' | 'classic' | 'premium'`), `category` (`'men' | 'women' | 'occasion' | 'unisex'`)
   - `priceNGN`, `description`, `fabric`, `availableSizes`, `stockCount`, `imagePath`

#### Interactive State Mapping & Handlers
- **Bespoke Commission Submission**: Validates contact info and custom choices $\to$ automatically assigns a new `KLM-XXXX` order code $\to$ creates a pending stage 1 order in the Atelier Store $\to$ displays confirmation with order tracking code and WhatsApp consultation prompt.
- **Order Stage Progression**: Studio manager clicks stage buttons $\to$ validates deposit before entering production $\to$ updates timestamp and appends history log $\to$ triggers toast notification.
- **Cost Engine Auto-Calculation**: Live computation of total cost, profit margin, retail quote in Nigerian Naira (₦), and recommended 60% deposit upon typing material or labor figures.
- **Measurement Export & WhatsApp Copy**: Formats the client card or invoice into a neat plain-text template ready for 1-click clipboard copy to WhatsApp.
